
# Taylor Rule Pro (Extended Toolkit)

**Features**
- Baseline / lags / pressure specifications
- OLS + Newey–West (HAC) standard errors
- Rolling and expanding coefficient paths
- Out-of-sample evaluation (RMSE/MAE/MAPE)
- In-sample fit and residual plots
- Simple 1-step "forecast" export
- Markdown report with key results

**Run on sample**
```bash
python -m taylor_pro.cli --data taylor_pro/sample_macro_data.csv --spec pressure --pi_star 2.0 --hac_lags 4 --rolling 48 --expanding 48 --outdir taylor_pro
```
Artifacts go into `taylor_pro/results/` and `taylor_pro/figures/`.
