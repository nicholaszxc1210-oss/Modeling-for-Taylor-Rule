
import numpy as np
import pandas as pd

def ols(X, y, ridge=1e-8):
    XtX = X.T @ X + ridge*np.eye(X.shape[1])
    Xty = X.T @ y
    beta = np.linalg.solve(XtX, Xty)
    resid = y - X @ beta
    dof = max(1, X.shape[0]-X.shape[1])
    s2 = (resid @ resid) / dof
    vcov = s2 * np.linalg.inv(XtX)
    se = np.sqrt(np.diag(vcov))
    return beta, se, resid

def newey_west_se(X, resid, L=4):
    """
    Newey-West HAC covariance with lag length L.
    """
    n, k = X.shape
    # meat of sandwich
    S = np.zeros((k, k))
    u = resid
    Z = X * u[:, None]
    Gamma0 = Z.T @ Z / n
    S = Gamma0.copy()
    for l in range(1, L+1):
        w = 1 - l/(L+1)
        Gamma_l = (Z[l:].T @ Z[:-l]) / n
        S += w*(Gamma_l + Gamma_l.T)
    XtX_inv = np.linalg.inv(X.T @ X / n)
    V = XtX_inv @ S @ XtX_inv / n
    se = np.sqrt(np.diag(V))
    return V, se

def train_test_split_idx(n, test_size=0.2):
    test_n = int(np.floor(n*test_size))
    train_end = n - test_n
    idx_train = np.arange(0, train_end)
    idx_test = np.arange(train_end, n)
    return idx_train, idx_test

def rmse(a, f):
    return float(np.sqrt(np.mean((a-f)**2)))

def mae(a, f):
    return float(np.mean(np.abs(a-f)))

def mape(a, f, eps=1e-6):
    denom = np.maximum(np.abs(a), eps)
    return float(np.mean(np.abs(a-f)/denom))

def acf(x, nlags=20):
    x = np.asarray(x) - np.mean(x)
    n = len(x)
    auto = np.correlate(x, x, mode='full')[n-1: n+nlags]
    return auto / auto[0]
