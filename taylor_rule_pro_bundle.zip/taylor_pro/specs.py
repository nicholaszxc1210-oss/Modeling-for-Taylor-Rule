
def design_matrix(df, pi_star=2.0, spec="baseline"):
    """
    Return (X, y, names) for the requested specification.

    y = i_t - pi_t (nominal minus inflation)
    baseline RHS: [1, (pi_t - pi_star), y_t]
    variants:
      - "baseline": as above
      - "lags1": add lagged inflation gap and lagged output gap
      - "pressure": add -pressure_t as an extra regressor
    """
    import numpy as np

    lhs = df["policy_rate"].values - df["inflation"].values
    pi_gap = df["inflation"].values - pi_star
    y_gap = df["output_gap"].values

    if spec == "baseline":
        X = np.column_stack([np.ones(len(df)), pi_gap, y_gap])
        names = ["r_star", "phi_pi", "phi_y"]
    elif spec == "lags1":
        # requires lags; drop first row
        pi_gap_l1 = np.concatenate([[np.nan], pi_gap[:-1]])
        y_gap_l1 = np.concatenate([[np.nan], y_gap[:-1]])
        mask = (~np.isnan(pi_gap_l1)) & (~np.isnan(y_gap_l1))
        lhs = lhs[mask]
        X = np.column_stack([np.ones(mask.sum()), pi_gap[mask], y_gap[mask], pi_gap_l1[mask], y_gap_l1[mask]])
        names = ["r_star", "phi_pi", "phi_y", "phi_pi_l1", "phi_y_l1"]
    elif spec == "pressure":
        pres = df["pressure"].values if "pressure" in df.columns else None
        if pres is None:
            raise ValueError("pressure spec requested but 'pressure' column not found")
        X = np.column_stack([np.ones(len(df)), pi_gap, y_gap, -pres])
        names = ["r_star", "phi_pi", "phi_y", "kappa"]
    else:
        raise ValueError(f"Unknown spec: {spec}")
    return X, lhs, names
