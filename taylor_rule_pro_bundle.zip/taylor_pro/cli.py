
import argparse, json, os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path
from .estimator import TaylorRuleEstimator

def main():
    ap = argparse.ArgumentParser(description="Taylor Rule Pro Estimator")
    ap.add_argument("--data", required=True)
    ap.add_argument("--pi_star", type=float, default=2.0)
    ap.add_argument("--spec", choices=["baseline","lags1","pressure"], default="baseline")
    ap.add_argument("--hac_lags", type=int, default=4)
    ap.add_argument("--test_size", type=float, default=0.25)
    ap.add_argument("--rolling", type=int, default=0, help="Rolling window length (0 to skip)")
    ap.add_argument("--expanding", type=int, default=0, help="Expanding start length (0 to skip)")
    ap.add_argument("--outdir", default=".")
    args = ap.parse_args()

    df = pd.read_csv(args.data)
    if "date" in df.columns:
        try: df["date"] = pd.to_datetime(df["date"])
        except Exception: pass

    outdir = Path(args.outdir)
    (outdir / "figures").mkdir(parents=True, exist_ok=True)
    (outdir / "results").mkdir(parents=True, exist_ok=True)

    est = TaylorRuleEstimator(pi_star=args.pi_star, spec=args.spec, hac_lags=args.hac_lags)
    est.fit(df)
    summ = est.summary()
    summ.to_csv(outdir / "results" / "coef_summary.csv", index=False)
    (outdir / "results" / "coef_summary.json").write_text(summ.to_json(orient="records", indent=2))

    i_tr, i_adj = est.implied_policy(df)
    out = df.copy()
    out["taylor_implied"] = i_tr
    if i_adj is not None:
        out["pressure_adjusted_implied"] = i_adj
        out["wedge"] = out["taylor_implied"] - out["pressure_adjusted_implied"]
    out["residual"] = df["policy_rate"].values - i_tr
    out.to_csv(outdir / "results" / "series_with_fit.csv", index=False)

    # In-sample fit plot
    plt.figure()
    plt.plot(df["policy_rate"].values, label="Actual policy rate")
    plt.plot(i_tr, label="Taylor implied")
    if i_adj is not None:
        plt.plot(i_adj, label="Pressure-adjusted implied")
    plt.title("Policy: Actual vs. Implied")
    plt.xlabel("Time")
    plt.ylabel("Rate (pp)")
    plt.legend()
    plt.tight_layout()
    plt.savefig(outdir / "figures" / "fit.png", dpi=200)
    plt.close()

    # Residuals
    plt.figure()
    plt.plot(out["residual"].values, label="Residual")
    plt.title("Residuals over time")
    plt.xlabel("Time")
    plt.ylabel("pp")
    plt.tight_layout()
    plt.savefig(outdir / "figures" / "residuals.png", dpi=200)
    plt.close()

    # Out-of-sample evaluation
    metrics, (idx_tr, idx_te) = est.evaluate_oos(df, test_size=args.test_size)
    (outdir / "results" / "oos_metrics.json").write_text(json.dumps(metrics, indent=2))

    # Coefficient paths (rolling / expanding)
    if args.rolling > 0:
        names, coefs = est.rolling_fit(df, window=args.rolling)
        for j, name in enumerate(names):
            plt.figure()
            plt.plot(coefs[:, j], label=name)
            plt.title(f"Rolling {args.rolling}-window coefficient: {name}")
            plt.xlabel("Window end index")
            plt.ylabel("Estimate")
            plt.tight_layout()
            plt.savefig(outdir / "figures" / f"coef_rolling_{name}.png", dpi=200)
            plt.close()

    if args.expanding > 0:
        names, coefs = est.expanding_fit(df, start=args.expanding)
        for j, name in enumerate(names):
            plt.figure()
            plt.plot(coefs[:, j], label=name)
            plt.title(f"Expanding (start={args.expanding}) coefficient: {name}")
            plt.xlabel("Sample end index")
            plt.ylabel("Estimate")
            plt.tight_layout()
            plt.savefig(outdir / "figures" / f"coef_expanding_{name}.png", dpi=200)
            plt.close()

    # Simple forecast demo (1-step ahead using last observed X structure)
    # We reuse implied policy for the terminal point as "forecast"; real extension could add VAR.
    if "date" in df.columns:
        date_col = df["date"]
    else:
        date_col = np.arange(len(df))
    last_i = float(i_tr[-1])
    (outdir / "results" / "forecast_1step.json").write_text(json.dumps({"last_implied_policy": last_i}, indent=2))

    # Markdown report
    report = []
    report.append("# Taylor Rule Pro — Report\n")
    report.append(f"- Spec: **{args.spec}**, pi*: **{args.pi_star}**, HAC lags: **{args.hac_lags}**\n")
    report.append("## Coefficient Summary\n")
    report.append(summ.to_markdown(index=False))
    report.append("\n\n## Out-of-sample metrics\n")
    report.append("```\n" + json.dumps(metrics, indent=2) + "\n```\n")
    report.append("\nFigures saved in `figures/`.\n")
    (outdir / "results" / "report.md").write_text("\n".join(report))

    print("Done. Results in", outdir)

if __name__ == "__main__":
    main()
