# Taylor Rule Pro — Report

- Spec: **pressure**, pi*: **2.0**, HAC lags: **4**

## Coefficient Summary

| param   |     coef |    se_ols |    se_hac |
|:--------|---------:|----------:|----------:|
| r_star  | 0.600614 | 0.01346   | 0.0112972 |
| phi_pi  | 1.35028  | 0.0222283 | 0.0240033 |
| phi_y   | 0.461085 | 0.0291723 | 0.0357837 |
| kappa   | 0.432544 | 0.0397491 | 0.0255429 |


## Out-of-sample metrics

```
{
  "train_rmse": 0.18639631339208554,
  "test_rmse": 0.23838446881772346,
  "train_mae": 0.15106230608623716,
  "test_mae": 0.19229012498535825,
  "train_mape": 0.15663084101339317,
  "test_mape": 0.0837506717356722
}
```


Figures saved in `figures/`.
