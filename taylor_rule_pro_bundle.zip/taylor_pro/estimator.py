
import numpy as np
import pandas as pd
from .utils import ols, newey_west_se, train_test_split_idx, rmse, mae, mape, acf
from . import specs as S

class TaylorRuleEstimator:
    def __init__(self, pi_star=2.0, spec="baseline", hac_lags=4):
        self.pi_star = pi_star
        self.spec = spec
        self.hac_lags = hac_lags
        self.beta_ = None
        self.se_ = None
        self.se_hac_ = None
        self.names_ = None
        self.resid_ = None
        self.fit_rows_ = None

    def fit(self, df):
        X, lhs, names = S.design_matrix(df, pi_star=self.pi_star, spec=self.spec)
        beta, se, resid = ols(X, lhs)
        _, se_hac = newey_west_se(X, resid, L=self.hac_lags)
        self.beta_, self.se_, self.se_hac_ = beta, se, se_hac
        self.names_, self.resid_ = names, resid
        self.fit_rows_ = len(lhs)
        return self

    def summary(self):
        rows = []
        for i, n in enumerate(self.names_):
            rows.append({"param": n, "coef": float(self.beta_[i]), "se_ols": float(self.se_[i]), "se_hac": float(self.se_hac_[i])})
        return pd.DataFrame(rows)

    def implied_policy(self, df):
        # compute Taylor implied (without pressure wedge)
        pi = df["inflation"].values
        y  = df["output_gap"].values
        r_star = self.get_coef("r_star")
        phi_pi = self.get_coef("phi_pi")
        phi_y  = self.get_coef("phi_y")
        i_tr = r_star + pi + phi_pi*(pi - self.pi_star) + phi_y*y
        # pressure-adjusted if present in spec & data
        i_adj = None
        if ("kappa" in self.names_) and ("pressure" in df.columns):
            kappa = self.get_coef("kappa")
            i_adj = i_tr - kappa * df["pressure"].values
        return i_tr, i_adj

    def get_coef(self, name):
        idx = self.names_.index(name)
        return float(self.beta_[idx])

    def rolling_fit(self, df, window=40):
        X, lhs, names = S.design_matrix(df, pi_star=self.pi_star, spec=self.spec)
        coefs = []
        for end in range(window, len(lhs)+1):
            beta, _, resid = ols(X[end-window:end], lhs[end-window:end])
            coefs.append(beta)
        coefs = np.array(coefs)
        return names, coefs

    def expanding_fit(self, df, start=40):
        X, lhs, names = S.design_matrix(df, pi_star=self.pi_star, spec=self.spec)
        coefs = []
        for end in range(start, len(lhs)+1):
            beta, _, resid = ols(X[:end], lhs[:end])
            coefs.append(beta)
        coefs = np.array(coefs)
        return names, coefs

    def evaluate_oos(self, df, test_size=0.2):
        # train/test split for implied rates
        n = len(df)
        idx_tr, idx_te = train_test_split_idx(n, test_size=test_size)
        df_tr, df_te = df.iloc[idx_tr], df.iloc[idx_te]
        self.fit(df_tr)
        i_tr_tr, i_adj_tr = self.implied_policy(df_tr)
        i_tr_te, i_adj_te = self.implied_policy(df_te)
        out = {
            "train_rmse": rmse(df_tr["policy_rate"].values, i_tr_tr),
            "test_rmse":  rmse(df_te["policy_rate"].values, i_tr_te),
            "train_mae":  mae(df_tr["policy_rate"].values, i_tr_tr),
            "test_mae":   mae(df_te["policy_rate"].values, i_tr_te),
            "train_mape": mape(df_tr["policy_rate"].values, i_tr_tr),
            "test_mape":  mape(df_te["policy_rate"].values, i_tr_te),
        }
        return out, (idx_tr, idx_te)
